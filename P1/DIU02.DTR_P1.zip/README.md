## DIU - Practica1, entregables

Aqui adjunto cada unos de los entregables de la practica 1:

- User research - (plan) template:
  - [User Research Plan](P1-2b%20User%20Research%20Plan%20Template.pdf)

- Desk research: Análisis Competencia:
  - [Competivive Analysis PDF](Competitor%20Analysis%20DTR.pdf)
  
- 2 Personas y 2 User Journey Map  (1 por persona):
  - [Persona Journey Map](PersonasJourneyMap.pdf)
  
- Revisión de Usabilidad:
  
  - [Usability Review](Usability-review.xlsx%20-%20Usability%20scores.pdf) 


Y por ultimo adjunto el documento con las conclusiones de cada uno de los archivos:

[Documento Conclusiones](ConclusionesP1.pdf) 
